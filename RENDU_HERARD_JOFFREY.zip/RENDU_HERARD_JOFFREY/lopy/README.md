# LoRa models for LoPy

This part of the project got 2 directory:
* Test directory: contain test file   
* Current: contain current file in development
